# import os
# import boto3
# from boto3.s3.transfer import S3Transfer
#
# local_directory = '/home/shadowk/PycharmProjects/Programs_BridgeLab/FundooProject/fundoonote/fundooapp'
# transfer = S3Transfer(boto3.client('s3'))
# client = boto3.client('s3')
# bucket = 'django-s3-assets1'
# for root, dirs, files in os.walk(local_directory):
#     for filename in files:
#         local_path = os.path.join(root, 'djang1.pdf')
#         relative_path = os.path.relpath(local_path, local_directory)
#         s3_path = os.path.join('Your s3 path',relative_path)
#         if filename.endswith('.pdf'):
#             transfer.upload_file(local_path, bucket, s3_path,extra_args={'ACL': 'private-read'})
#         else:
#             transfer.upload_file(local_path, bucket, s3_path)
#

# import boto3
# import jwt
# from django.contrib.auth.models import User
# from django.http import HttpResponse, JsonResponse
# from  django.contrib import messages
# from redis import redis_methods
#
#
# class S3Upload:
#     def uploadto_aws(request, uploaded_file):
#         """ this method is used to upload a pic aws s3 bucket"""
#         res = {}
#         try:
#             if request.method == 'POST':
#                 # uploaded_file = request.FILES['document']   # taking the file from local
#                 # uploaded_file = open(path, 'rb')  # image to upload with read access
#                 token = redis_methods.get_value(self, 'token')
#                 token_decode = jwt.decode(token, 'secret_key', algorithms=['HS256'])
#                 # token_decode = jwt.decode(token, os.getenv("SIGNATURE"), algorithms=['HS256'])
#                 print("TOKEN DECODE", token_decode)
#                 uname = token_decode.get('username')
#                 user = User.objects.get(username=uname)
#                 auth_user = request.user_id
#                 file_nam = str(user)       # taking file name in string
#                 file_name = file_nam+".jpg"
#                 print("filename", file_name)
#                 s3 = boto3.client('s3')     # using boto to upload file in aws s3 bucket
#
#                 s3.upload_fileobj(uploaded_file, 'django-s3-assets1', Key=file_name)
#                 url = '{}/{}/{}'.format(s3.meta.endpoint_url, 'django-s3-assets1', file_name)  # HERE WE GET THE URL OF THE FILE
#                 print("myurl", url)
#                 if awsfilepath.objects.filter(user_id=auth_user).exists():
#                     # if the user profile is already present it will pass or else it will save the path in db
#                     pass
#                 else:
#                     data = awsfilepath(filename=url, user_id=auth_user)
#                     data.save()     # saving the data in db
#                 messages.success(request, "successfully uploaded", extra_tags='alert')
#         except (FileNotFoundError, ValueError, IOError):
#             res['message'] = 'something bad happend'
#             return JsonResponse(res, status=404)